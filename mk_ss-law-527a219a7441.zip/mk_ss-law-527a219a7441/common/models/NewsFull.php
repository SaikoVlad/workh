<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "news_full".
 *
 * @property integer $id
 * @property integer $news_id
 * @property string $content
 * @property string $lang
 * @property string $title
 *
 * @property News $news
 */
class NewsFull extends \yii\db\ActiveRecord
{
    //TODO: переделать в NEWS модель.
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'news_full';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['news_id'], 'integer'],
            [['content'], 'string'],
            [['lang'], 'string', 'max' => 5],
            [['title'], 'string', 'max' => 255],
            [['news_id'], 'exist', 'skipOnError' => true, 'targetClass' => News::className(), 'targetAttribute' => ['news_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'news_id' => Yii::t('app', 'News ID'),
            'content' => Yii::t('app', 'Content'),
            'lang' => Yii::t('app', 'Lang'),
            'title' => Yii::t('app', 'Title'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNews()
    {
        return $this->hasOne(News::className(), ['id' => 'news_id']);
    }
}

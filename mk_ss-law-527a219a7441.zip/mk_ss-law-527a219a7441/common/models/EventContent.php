<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "event_content".
 *
 * @property integer $id
 * @property integer $event_id
 * @property string $lang
 * @property string $title
 * @property string $meta_descr
 * @property string $meta_keys
 * @property string $body
 *
 * @property Event $event
 */
class EventContent extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'event_content';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['event_id'], 'integer'],
            [['body'], 'string'],
            [['lang'], 'string', 'max' => 5],
            [['title', 'meta_descr', 'meta_keys'], 'string', 'max' => 255],
            [['event_id'], 'exist', 'skipOnError' => true, 'targetClass' => Event::className(), 'targetAttribute' => ['event_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'event_id' => Yii::t('app', 'Event ID'),
            'lang' => Yii::t('app', 'Lang'),
            'title' => Yii::t('app', 'Title'),
            'meta_descr' => Yii::t('app', 'Meta Descr'),
            'meta_keys' => Yii::t('app', 'Meta Keys'),
            'body' => Yii::t('app', 'Body'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEvent()
    {
        return $this->hasOne(Event::className(), ['id' => 'event_id']);
    }
}

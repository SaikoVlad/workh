<?php

namespace common\models;

use Yii;
use yii\behaviors\TimestampBehavior;

/**
 * This is the model class for table "univer".
 *
 * @property integer $id
 * @property string $name
 * @property string $descr
 * @property string $country
 * @property string $city
 * @property string $contacts
 * @property double $rating
 * @property string $gerb
 * @property string $location
 * @property string $fb
 * @property string $vk
 * @property string $tw
 * @property string $li
 * @property integer $created_at
 * @property integer $updated_at
 * @property integer $visible
 * @property integer $order
 */
class Univer extends \yii\db\ActiveRecord
{
    public $image;

    private $_rate;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'univer';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['descr', 'contacts'], 'string'],
            [['rating'], 'number'],
            [['image'], 'file', 'extensions' => 'png, jpg'],
            [['visible', 'order'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['country', 'city', 'gerb'], 'string', 'max' => 50],
            [['location'], 'string', 'max' => 200],
            [['fb', 'vk', 'tw', 'li'], 'string', 'max' => 128],
        ];
    }

    public function upload()
    {
        if ($this->validate()) {
            var_dump($this->image);
        } else {
            return false;
        }
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'descr' => Yii::t('app', 'Descr'),
            'country' => Yii::t('app', 'Country'),
            'city' => Yii::t('app', 'City'),
            'contacts' => Yii::t('app', 'Contacts'),
            'rating' => Yii::t('app', 'Rating'),
            'gerb' => Yii::t('app', 'Gerb'),
            'location' => Yii::t('app', 'Location'),
            'fb' => Yii::t('app', 'Fb'),
            'vk' => Yii::t('app', 'Vk'),
            'tw' => Yii::t('app', 'Tw'),
            'li' => Yii::t('app', 'Li'),
            'created_at' => 'Created At',
            'updated_at' => 'Update At',
            'visible' => Yii::t('app', 'Visible'),
            'order' => Yii::t('app', 'Order'),
        ];
    }

    public function getProfiles()
    {
        return $this->hasMany(Profile::className(), ['id' => 'profile_id'])
            ->viaTable('univer_profile', ['univer_id' => 'id']);
    }

    public function getTeams()
    {
        return $this->hasMany(Team::className(), ['univer_id' => 'id']);
    }

    public function getGerbSrc()
    {
        return Yii::getAlias('@web') . '../uploads/' . $this->gerb;
    }

    public static function getListSelect2()
    {
        $all = Univer::find()->all();
        $result = [];
        foreach ($all as $one) {
            $result[$one->id] = $one->name;
        }
        sort($result);
        return $result;
    }

    public function getEvents()
    {
        $arr = [];

        /**
         * @var Team $team
         */
        foreach ($this->teams as $team) {
            foreach ($team->events as $event) {
                $arr[$event->id] = $event;
            }
        }

        return $arr;
    }

    public function getRate()
    {
        $rate = 0;
        $events = $this->getEvents();

        foreach ($events as $event){
            $allTeamRate = [];
            foreach ($event->getTeamUniver($this->id)->all() as $team){
                $allTeamRate [$team->getResultEvent($event)['position']] = $team->getResultEvent($event)['rate'];
           }
            ksort($allTeamRate);
            $rate = $rate + current($allTeamRate);
        }

        return $rate;
    }

//    public function getRate()
//    {
//        $events = $this->getEvents();
//
//
//    }
}

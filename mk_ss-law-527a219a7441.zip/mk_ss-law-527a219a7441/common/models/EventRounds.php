<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "event_rounds".
 *
 * @property integer $id
 * @property integer $event_id
 * @property integer $date_from
 * @property integer $date_to
 * @property double $weight
 * @property string $comment
 * @property integer $visible
 * @property integer $status
 * @property integer $title
 *
 * @property Events $event
 */
class EventRounds extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'event_rounds';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['event_id', 'date_from', 'date_to', 'visible'], 'integer'],
//            [['weight'], 'number'],
            [['comment', 'title'], 'string'],
            [['visible', 'status', 'weight'], 'safe'],
            [['event_id'], 'exist', 'skipOnError' => true, 'targetClass' => Event::className(), 'targetAttribute' => ['event_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'event_id' => Yii::t('app', 'Event ID'),
            'date_from' => Yii::t('app', 'Date From'),
            'date_to' => Yii::t('app', 'Date To'),
            'weight' => Yii::t('app', 'Weight'),
            'comment' => Yii::t('app', 'Comment'),
            'visible' => Yii::t('app', 'Visible'),
            'status' => Yii::t('app', 'Status'),
            'title' => Yii::t('app', 'Title'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEvent()
    {
        return $this->hasOne(Event::className(), ['id' => 'event_id']);
    }
}

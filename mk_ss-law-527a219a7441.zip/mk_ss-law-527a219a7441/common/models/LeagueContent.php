<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "league_content".
 *
 * @property integer $id
 * @property integer $league_id
 * @property string $lang
 * @property string $title
 * @property string $meta_title
 * @property string $meta_keys
 * @property string $meta_descr
 * @property string $body
 *
 * @property League $league
 */
class LeagueContent extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'league_content';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['league_id'], 'integer'],
            [['meta_descr', 'body'], 'string'],
            [['lang', 'title', 'meta_title', 'meta_keys'], 'string', 'max' => 50],
            [['league_id'], 'exist', 'skipOnError' => true, 'targetClass' => League::className(), 'targetAttribute' => ['league_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'league_id' => Yii::t('app', 'League ID'),
            'lang' => Yii::t('app', 'Lang'),
            'title' => Yii::t('app', 'Title'),
            'meta_title' => Yii::t('app', 'Meta Title'),
            'meta_keys' => Yii::t('app', 'Meta Keys'),
            'meta_descr' => Yii::t('app', 'Meta Descr'),
            'body' => Yii::t('app', 'Body'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLeague()
    {
        return $this->hasOne(League::className(), ['id' => 'league_id']);
    }
}

<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "team".
 *
 * @property integer $id
 * @property integer $univer_id
 * @property integer $last_round
 * @property string $title
 * @property string $faculty
 */
class Team extends \yii\db\ActiveRecord
{

    private $_rate;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'team';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['univer_id'], 'integer'],
            [['title', 'faculty'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'univer_id' => Yii::t('app', 'Univer'),
            'title' => Yii::t('app', 'Title'),
            'faculty' => Yii::t('app', 'Faculty'),
        ];
    }

    public function getProfiles()
    {
        return $this->hasMany(Profile::className(), ['id' => 'profile_id'])
            ->viaTable('team_profile', ['team_id' => 'id']);
    }

    public function getUniver()
    {
        return $this->hasOne(Univer::className(), ['id' => 'univer_id']);
    }

    public function getFullname()
    {
        return $this->event->league->name.'_'.$this->univer->name .'_'.date('Y', strtotime($this->event->date_from));
    }

    public function getEvent()
    {
        return $this->hasOne(Event::className(), ['id' => 'event_id']);
    }

    public static function getListSelect2()
    {
        $all = Team::find()->all();
        $result = [];
        foreach ($all as $one) {
            $result[$one->id] = $one->title;
        }
        return $result;
    }

    public function setRate($rate)
    {
        $this->_rate = $rate;
    }

    public function getRate()
    {
        $rate = 0;

//        foreach ($this->events as $event) {
//            $result = $event->getResultTeam($this);
//            $rate = $rate + $result['rate'];
//        }

        return $rate;
    }


    public function getCategory()
    {
        return $this->hasOne(Event::className(), ['id' => 'event_id']);
    }

    public function getResultEvent(Event $event)
    {
        $connection = Yii::$app->db;

        $result = $connection->createCommand('SELECT * FROM event_team WHERE `team_id` = :tId AND `event_id` = :eId', [
            ':tId' => $this->id,
            ':eId' => $event->id
        ])->queryOne();

        if (!$result['result'])
            return false;

        $position = $result['result'];
        $rate = (count($event->teams) * $event->weight) / ($position + $position + 1);

        return ['position' => $position, 'rate' => round($rate, 2)];
    }
}

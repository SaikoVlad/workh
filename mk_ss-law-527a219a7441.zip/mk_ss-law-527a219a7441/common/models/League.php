<?php

namespace common\models;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "league".
 *
 * @property integer $id
 * @property integer $parent_id
 * @property string $found_date
 * @property string $link
 * @property string $name
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property League $parent
 * @property League[] $leagues
 * @property LeagueContent[] $leagueContents
 */
class League extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'league';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['parent_id', 'created_at', 'updated_at'], 'integer'],
            [['found_date'], 'string', 'max' => 50],
            [['link', 'name'], 'string', 'max' => 255],
            [['parent_id'], 'exist', 'skipOnError' => true, 'targetClass' => League::className(), 'targetAttribute' => ['parent_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'parent_id' => Yii::t('app', 'Parent ID'),
            'found_date' => Yii::t('app', 'Found Date'),
            'link' => Yii::t('app', 'Link'),
            'name' => Yii::t('app', 'Base title'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getParent()
    {
        return $this->hasOne(League::className(), ['id' => 'parent_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getChild()
    {
        return $this->hasMany(League::className(), ['parent_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLeagueContents()
    {
        return $this->hasMany(LeagueContent::className(), ['league_id' => 'id']);
    }
    /**
     * @param string $lang
     * @return $this
     */
    public function getLeagueLangContent($lang = 'en')
    {
        return $this->hasMany(LeagueContent::className(), ['league_id' => 'id'])
            ->where('lang = :lang', [':lang' => $lang])
            ->orderBy('id')
            ->limit(1);
    }

    /**
     * @return mixed
     */
    public function getContent()
    {
        $cont = $this->getLeagueLangContent(Yii::$app->language)->one();
        return $cont;

    }

    public static function getParentList($id = null)
    {
        if ($id)
            $cats = self::find()
                ->where('id != :id', [':id' => $id])  //'id != :id and type != :type', ['id'=>1, 'type'=>1])
                ->all();
        else
            $cats = self::find()->all();

        return ArrayHelper::map($cats, 'id', 'name');
    }

    public static function getLeagueList($enabled = null)
    {
        if ($enabled)
            $league = self::find()->where(['enabled' => $enabled])->all();
        else
            $league = self::find()->all();

        $arr = ArrayHelper::toArray($league, [
            'common\models\League' => [
                'id',
                'name',
                'parent' => function ($val){
                    return $val->parent ? $id = $val->parent->name : '';
                },
                'child' => function ($val){
                    return $val->child ? 'true' : '';
                },
            ]
        ]);

        $result = [];
        foreach ($arr as $val){
            if(!empty($val['parent'])){
                $result[$val['parent']][$val['id']] = $val['name'];
            }
            if(empty($val['parent']) && empty($val['child'])){
                $result['With out parents Event'][$val['id']] = $val['name'];
            }
        }
        return $result;
    }
}

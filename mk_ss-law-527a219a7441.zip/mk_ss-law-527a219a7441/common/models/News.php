<?php

namespace common\models;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "news".
 *
 * @property integer $id
 * @property integer $category_id
 * @property string $link
 * @property string $meta_keys
 * @property string $meta_descr
 * @property integer $created_at
 * @property integer $updated_at
 * @property integer $visible
 *
 * @property NewsCategory $category
 * @property NewsFull[] $newsFullAll
 * @property NewsFull[] $newsLangContent
 */
class News extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'news';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['category_id', 'created_at', 'updated_at', 'visible', 'category_id'], 'integer'],
            [['link', 'meta_keys', 'meta_descr'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'category_id' => Yii::t('app', 'Category'),
            'link' => Yii::t('app', 'Link'),
            'meta_keys' => Yii::t('app', 'Meta Keys'),
            'meta_descr' => Yii::t('app', 'Meta Descr'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
            'visible' => Yii::t('app', 'Visible'),
        ];
    }

    public function getCategory()
    {
        return $this->hasOne(NewsCategory::className(), ['id' => 'category_id']);
    }



    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNewsFullAll()
    {
        return $this->hasMany(NewsFull::className(), ['news_id' => 'id']);
    }

    /**
     * @param $lang
     * @return \yii\db\ActiveQuery
     */
    public function getNewsLangContent($lang = 'en')
    {
        return $this->hasMany(NewsFull::className(), ['news_id' => 'id'])
            ->where('lang = :lang', [':lang' => $lang])
            ->orderBy('id')
            ->limit(1);
    }
}

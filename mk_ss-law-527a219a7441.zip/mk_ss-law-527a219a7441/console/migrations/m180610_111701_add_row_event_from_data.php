<?php

use yii\db\Migration;

/**
 * Class m180610_111701_add_row_event_from_data
 */
class m180610_111701_add_row_event_from_data extends Migration
{
    /**
     * @inheritdoc
     */
    public function safeUp()
    {
        $this->addColumn('events', 'date_to', $this->integer());
        $this->addColumn('events', 'date_from', $this->integer());
        $this->addColumn('events', 'count_rounds', $this->integer(2));
        $this->addColumn('team', 'last_round', $this->integer(2));
        $this->addColumn('team', 'event_id', $this->integer());
        $this->dropColumn('events', 'date_d');
    }

    /**
     * @inheritdoc
     */
    public function safeDown()
    {
        echo "m180610_111701_add_row_event_from_data cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m180610_111701_add_row_event_from_data cannot be reverted.\n";

        return false;
    }
    */
}

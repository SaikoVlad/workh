<?php

namespace backend\controllers;

use common\models\LeagueContent;
use Yii;
use common\models\League;
use backend\models\LeagueSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * LegueController implements the CRUD actions for League model.
 */
class LeagueController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all League models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LeagueSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single League model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new League model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new League();

        if ($post = Yii::$app->request->post()) {
            $post = Yii::$app->request->post();
            $model->load($post);
            if($model->save())
            {
                $leagueCont = $post['LeagueContent'];
                foreach ($leagueCont as $k => $item) {
                    $m = new LeagueContent();
                    $m->attributes = $item;
                    $m->league_id = $model->id;
//                    $m->content = $item['content'];
                    $m->save();
                }
            }
            return $this->redirect(['/league']);
        } else {
            return $this->render('create', [
                'model' => $model,
                'enContent' => current($model->getLeagueLangContent('en')->all()),
                'ruContent' => current($model->getLeagueLangContent('ru')->all()),
            ]);
        }
    }

    /**
     * Updates an existing League model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if($model)
        {
            $enContent = current($model->getLeagueLangContent('en')->all());
            $ruContent = current($model->getLeagueLangContent('ru')->all());
        }

        if ($post = Yii::$app->request->post()) {
//            $post = Yii::$app->request->post();
            $model->load($post);
            if($model->save())
            {
                $leagueCont = $post['LeagueContent'];
                foreach ($leagueCont as $k => $item) {
                    if($k == 'en'){
                        $m = $enContent;
                    }elseif($k == 'ru'){
                        $m = $ruContent;
                    }
                    $m->attributes = $item;
                    $m->save();
                }
            }
            return $this->redirect(['/league']);
        }else {
            return $this->render('update', [
                'model' => $model,
                'enContent' => $enContent,
                'ruContent' => $ruContent,
            ]);
        }
    }

    /**
     * Deletes an existing League model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the League model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return League the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = League::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}

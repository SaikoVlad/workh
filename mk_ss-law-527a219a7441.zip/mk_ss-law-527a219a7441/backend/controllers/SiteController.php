<?php
namespace backend\controllers;

use common\models\User;
use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;

/**
 * Site controller
 */
class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['login', 'error'],
                        'allow' => true,
                    ],
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                    [
                        'actions' => ['index', 'test'],
                        'allow' => true,
                        'roles' => ['canAdmin']
                    ]
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        $user = User::findOne(1);
//        $admin = Yii::$app->authManager->createRole('admin');
//        $admin->description = 'Администратор';
//        Yii::$app->authManager->add($admin);
//
//        $moder = Yii::$app->authManager->createRole('moder');
//        $moder->description = 'Модератор';
//        Yii::$app->authManager->add($moder);
//
//        $user = Yii::$app->authManager->createRole('user');
//        $moder->description = 'Пользователь';
//        Yii::$app->authManager->add($user);
//
//        $permit = Yii::$app->authManager->createPermission('canAdmin');
//        $permit->description = 'Право на доступ в админку';
//        Yii::$app->authManager->add($permit);
//
//        $role_a = Yii::$app->authManager->getRole('admin');
//        $role_m = Yii::$app->authManager->getRole('moder');
//
//        $permit = Yii::$app->authManager->getPermission('canAdmin');
//
//        Yii::$app->authManager->addChild($role_a, $permit);
//        Yii::$app->authManager->addChild($role_m, $permit);
//
//


//        $user = new User();
//        $user->username = 'test';
//        $user->email = 'test@law.loc';
//        $user->setPassword('moder');
//        $user->generateAuthKey();
//        if ($user->save()) {
//            echo 'good';
//        }
//
//        $userRole = Yii::$app->authManager->getRole('user');
//        Yii::$app->authManager->assign($userRole, 2);

        return $this->render('index');
    }

    public function actionTest()
    {
        p('dsgdsh');
    }


    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }
}

<?php

namespace backend\controllers;

use common\models\Team;
use Yii;
use common\models\Univer;
use backend\models\UniverSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * UniverController implements the CRUD actions for Univer model.
 */
class UniverController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Univer models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new UniverSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Univer model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $profiles = $model->getProfiles()->all();

        return $this->render('view', [
            'model' => $model,
            'profiles' => $profiles
        ]);
    }

    /**
     * Creates a new Univer model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Univer();

        if ($model->load(Yii::$app->request->post())) {

            if (UploadedFile::getInstance($model, 'image')) {
                $image = $this->gerbSave(UploadedFile::getInstance($model, 'image'));
                if (!empty($image)) {
                    $model->gerb = $image;
                }
            }
            $model->save();
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    public function gerbSave($image)
    {
        $imageName = time() . '.' . $image->extension;
        $image->saveAs(Yii::getAlias('@backend') . '/uploads/' . $imageName);

        return $imageName;
    }

    /**
     * Updates an existing Univer model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post())) {

            if (UploadedFile::getInstance($model, 'image')) {
                $image = $this->gerbSave(UploadedFile::getInstance($model, 'image'));
                if (!empty($image)) {
                    $model->gerb = $image;
                }
            }
            $model->save();

            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    public function actionAddstudents()
    {
        if (Yii::$app->request->isAjax) {

            $post = Yii::$app->request->post('univerId');
            $arr = [];
            foreach (Yii::$app->request->post('studentId') as $item) {
                $arr[] = [$item, $post];
            }

            $connection = Yii::$app->db;
            $connection->createCommand()->batchInsert('univer_profile', ['profile_id', 'univer_id'],
                $arr)->execute();
            $model = $this->findModel(Yii::$app->request->post('univerId'));
        }

        return $this->renderAjax('_addstudents', ['model' => $model]);
    }

    public function actionAddteam()
    {
        if (Yii::$app->request->isAjax) {
            $post = Yii::$app->request->post();
            $team = new Team();
            $team->title = $post['title'];
            $team->faculty = $post['faculty'];
            $team->univer_id = $post['univerId'];

            if ($team->save() && (isset($post['studentId']) && !empty($post['studentId']))) {
                $arrTeam = [];
                $arrUniver = [];
                foreach ($post['studentId'] as $item) {
                    $arrTeam[] = [$item, $team->id];
                    $arrUniver[] = [$item, $post['univerId']];
                }

                $connection = Yii::$app->db;
                $connection->createCommand()->batchInsert('team_profile', ['profile_id', 'team_id'],
                    $arrTeam)->execute();
                $connection->createCommand()->batchInsert('univer_profile', ['profile_id', 'univer_id'],
                    $arrUniver)->execute();

            }
            $model = $this->findModel($post['univerId']);
        }

        return $this->renderAjax('_addteam', ['model' => $model]);
    }

    /**
     * Deletes an existing Univer model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Univer model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Univer the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Univer::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}

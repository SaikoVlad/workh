<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Univer;

/**
 * UniverSearch represents the model behind the search form about `common\models\Univer`.
 */
class UniverSearch extends Univer
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'created_at', 'updated_at', 'visible', 'order'], 'integer'],
            [['name', 'descr', 'country', 'city', 'contacts', 'gerb', 'location', 'fb', 'vk', 'tw', 'li'], 'safe'],
            [['rating'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Univer::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'rating' => $this->rating,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'visible' => $this->visible,
            'order' => $this->order,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['like', 'descr', $this->descr])
            ->andFilterWhere(['like', 'country', $this->country])
            ->andFilterWhere(['like', 'city', $this->city])
            ->andFilterWhere(['like', 'contacts', $this->contacts])
            ->andFilterWhere(['like', 'gerb', $this->gerb])
            ->andFilterWhere(['like', 'location', $this->location])
            ->andFilterWhere(['like', 'fb', $this->fb])
            ->andFilterWhere(['like', 'vk', $this->vk])
            ->andFilterWhere(['like', 'tw', $this->tw])
            ->andFilterWhere(['like', 'li', $this->li]);

        return $dataProvider;
    }
}

<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

$gii = true;
if($gii) {
    defined('YII_DEBUG') or define('YII_DEBUG', true);
    defined('YII_ENV') or define('YII_ENV', 'dev');
}else {
    defined('YII_DEBUG') or define('YII_DEBUG', false);
    defined('YII_ENV') or define('YII_ENV', 'prod');
}
//defined('YII_DEBUG') or define('YII_DEBUG', true);
//defined('YII_ENV') or define('YII_ENV', 'prod');

require(__DIR__ . '/../../vendor/autoload.php');
require(__DIR__ . '/../../vendor/yiisoft/yii2/Yii.php');
require(__DIR__ . '/../../common/config/bootstrap.php');
require(__DIR__ . '/../config/bootstrap.php');

$config = yii\helpers\ArrayHelper::merge(
    require(__DIR__ . '/../../common/config/main.php'),
    require(__DIR__ . '/../config/main.php')
//    require(__DIR__ . '/../../common/config/main-local.php'),
//    require(__DIR__ . '/../config/main-local.php')
);

if (YII_ENV_DEV) {
    $config['bootstrap'][] = 'gii';
    $config['components']['urlManager'] = [
        'enablePrettyUrl' => false,
        'showScriptName' => true,
    ];
}

(new yii\web\Application($config))->run();


function p($text, $exit = false)
{
//    if (!in_array(@$_SERVER['REMOTE_ADDR'], array('127.0.0.1', '::1'))) return ;

    if (is_callable('debug_backtrace')) {
        $trace = debug_backtrace();
        $title = $trace[0]['file'] . ':' . $trace[0]['line'];
    }
    $style = '<style>.debug-trace{ background: #ccc; padding: 10px; border: 1px solid #000; } .debug-trace-title{ font-size: 10px;  } .debug-trace pre{ border-left: 1px solid #000; padding: 5px; }</style>';
    $output = $style. '<div class="debug-trace">';
    $output.= '<div class="debug-trace-title">'. $title . '</div>';
    $output.= "<pre>";
    $output.= print_r($text, true);
    $output.= "</pre>";
    $output.= "</div>";
    echo $output;
    if ($exit) exit;
}

function getmicrotime()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

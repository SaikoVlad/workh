<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\EventSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Events');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="event-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create a New Moot Cour'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php Pjax::begin(); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

//            [
//                'label' => 'Title',
//                'value' => function ($data) {
//                    return $data->getCreateTitle();
//                }
//            ],
            [
//                'attribute' => 'status',
                'label' => 'Title',
                'format' => 'raw',
//                'filter' => \common\models\Event::getItemAlias('status'),
                'value' => function ($model) {
                    return $model->league->name . ' '. date('Y',strtotime($model->date_from));
                }
            ],

//            [
//                'attribute' => 'date_d',
////                'filter' =>
//                'value' => function ($data) {
//                    return date('d.m.Y', $data->date_d);
//                },
//            ],
            [
                'attribute' => 'status',
                'label' => 'Status',
                'format' => 'raw',
                'filter' => \common\models\Event::getItemAlias('status'),
                'value' => function ($model) {
                    return \common\models\Event::getStatusLabel($model->status);
                }
            ],
//            [
//                'attribute' => 'type',
//                'label' => Yii::t('app', 'Type'),
//                'format' => 'raw',
//                'filter' => \common\models\Event::getItemAlias('type'),
//                'value' => function($data) {
//                    return \common\models\Event::getItemAlias('type',$data->type);
//                }
//            ],

            ['class' => 'yii\grid\ActionColumn',
                'template' => '{view} {update} {delete}'],
        ],
    ]); ?>
    <?php Pjax::end(); ?></div>

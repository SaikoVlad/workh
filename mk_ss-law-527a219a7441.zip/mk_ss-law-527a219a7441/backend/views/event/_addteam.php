<?php
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\widgets\Pjax;

?>

<?php
$data = \common\models\Team::getListSelect2();
?>

<?php $form = ActiveForm::begin([
    'id' => 'add_form',
    'options' => ['data-pjax' => true, 'class' => 'form-horizontal'],
    'action' => ['addteams'],
    'fieldConfig' => ['template' => "<div class=\"col-md-12\">{label}{input}</div>",],
]); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 ">
            <?= Html::hiddenInput('eventId', $model->id) ?>
            <div class="form-group field-team-title">
                <?= Html::tag('label', Yii::t('app', 'Teams',['class' => 'control-label']))?>
            <?echo  Select2::widget([
                'name' => 'teamId',
                'data' => $data,
                'theme' => Select2::THEME_DEFAULT,
                'options' => ['placeholder' => Yii::t('app','Select teams'). '...','multiple' => true],
                'pluginOptions' => [
                    'allowClear' => true,
                    'class' => 'form-control'
                ],
            ]);
            ?>

        </div>
    </div>
</div>
<div class="box-footer col-align-right">
    <?= Html::submitButton(Yii::t('app', 'Add'), ['class' => 'btn btn-success']) ?>
    <?= Html::button(Yii::t('app','Close'), ['value' => '#', 'title' => 'close', 'class' => 'btn btn-warning', 'data-dismiss' => 'modal']) ?>
</div>

<?php ActiveForm::end(); ?>

<script type="text/javascript">
    $('#add_form').on('beforeSubmit', function (e) {
        e.preventDefault();
        var $form = $(this);

        $.post($form.attr("action"), $form.serialize())
            .done(function (result) {
//                console.log('done');
                $.pjax.reload({container: '#teamList'});
//                $.pjax.reload({container: '#univerMemb'});
                $('.modal').modal('hide');
            })
            .fail(function () {
                console.log("error");
            });
        return false;
    });
</script>
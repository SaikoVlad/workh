<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Event */
//
//$this->title = Yii::t('app', 'Update {modelClass}: ', [
//    'modelClass' => 'Event',
//]) . $model->id;
$this->title = 'Event wizzard';
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Events'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="event-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('wizzard/_createForm', [
        'model' => $model,
        'enContent' => $enContent,
        'ruContent' => $ruContent,
    ]) ?>

</div>

<?php

use common\models\Event;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\widgets\Pjax;

$this->registerJsFile('https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js');
$this->registerJsFile('https://unpkg.com/axios/dist/axios.min.js');
$this->registerCssFile('https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css');
/* @var $this yii\web\View */
/* @var $model common\models\Event */
/* @var $form yii\widgets\ActiveForm */
?>
<?php $form = ActiveForm::begin(); ?>

<div class="nav-tabs-custom">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#eventInfo" data-toggle="tab" aria-expanded="false"><b><?= Yii::t('app', "Step") ?>
                    1:</b> Event Info</a></li>
        <li class=""><a href="#teamsInfo" data-toggle="tab" aria-expanded="false"><b><?= Yii::t('app', "Step") ?>
                    2:</b> Members Info</a></li>
        <li><?= Html::submitButton('Save event or finish him', ['class' => 'btn btn-success']) ?></li>
    </ul>
    <div class="tab-content" id="eventCreateInfo">
        <div class="tab-pane active" id="eventInfo">
            <div class="row">
                <div class="col-md-12 news-form">
                    <div class="box-header with-border">
                    </div>
                    <div class="box-body">
                        <div class="col-md-3">
                            <div class="form-group field-team-title">
                                <?= Html::tag('label', Yii::t('app', 'League',['class' => 'control-label']))?>
                                <?echo  Select2::widget([
                                    'name' => 'Event[league_id]',
                                    'data' => \common\models\League::getLeagueList(),
                                    'theme' => Select2::THEME_DEFAULT,
                                    'options' => ['placeholder' => Yii::t('app','Select event'). '...','multiple' => false],
                                    'pluginOptions' => [
                                        'allowClear' => true,
                                        'class' => 'form-control',

                                    ],
                                    'value'=>$model->league_id
                                ]);
                                ?>
                            </div>

<!--                            --><?//= $form->field($model, 'link')->textInput(); ?>

                            <?= $form->field($model, 'count_rounds')->textInput()->label('Total Number of Rounds'); ?>

                            <?= $form->field ($model, 'date_from')->widget (
                                    DatePicker::className (), [
                                    'name' => 'date_from',
                                    'type' => DatePicker::TYPE_INPUT,
                                    'options' => [
                                        'style' => 'width: 150px',
                                        'placeholder' => 'Select issue date from...',
                                    ],
                                    'pluginOptions' => [
                                        'todayHighlight' => true,
                                        'format' => 'yyyy-m-d',
                                        'autoClose' => true,
                                    ],
                                ]);
                            ?>
                            <?= $form->field($model, 'date_to')->widget(
                                    DatePicker::className (), [
                                    'name' => 'date_to',
                                    'type' => DatePicker::TYPE_INPUT,
                                    'options' => [
                                        'style' => 'width: 150px',
                                        'placeholder' => 'Select issue date to...',
                                    ],
                                    'pluginOptions' => [
                                        'todayHighlight' => true,
                                        'format' => 'yyyy-m-d',
                                        'autoClose' => true,
                                    ],
                                ]);
                            ?>

                            <?= $form->field($model, 'status')->dropDownList(Event::getItemAlias('status')); ?>

                            <?php $model->visible = 1; ?>
                            <?= $form->field($model, 'visible')->checkbox(['value'=>'1', 'checked' => true]) ?>
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="form-group">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.tab-pane -->
        <div class="tab-pane" id="teamsInfo">
            <table id="univers_table" class="table table-bordered table-hover dataTable" role="grid"
                   aria-describedby="univers_table_info">
                <thead>
                <tr role="row">
                    <th tabindex="0" aria-controls="univers_table" rowspan="1" colspan="1"
                        aria-sort="ascending" aria-label="Univer: activate to sort column descending">
                        School
                    </th>
                    <th tabindex="0" aria-controls="univers_table" rowspan="1" colspan="1"
                        aria-label="Members: activate to sort column ascending">Team Members
                    </th>
                    <th>Last round</th>
                </tr>
                </thead>
                <tbody>
                    <?php foreach ($model->teams as $team):?>
                    <tr>
                        <td>
                            <?= Html::encode($team->getFullname())?>
                        </td>
                        <td>
                            <?php foreach ( $team->profiles as $profile):?>
                                <p>
                                        <?= $profile->fullname;?>
                                </p>
                            <?php endforeach;?>
                        </td>
                        <td>
                            <?= Html::encode( $team->last_round)?>
                        </td>
                    </tr>
                    <?php endforeach;?>

                    <tr v-for="(team, idx) in teams">
                        <td @dblclick="deleteTeam(idx)">
                            <select class="form-control" :name="'NewTeams['+idx+'][title]'">
                                <option> </option>
                                <?php foreach (\common\models\Univer::getListSelect2() as $id => $univer):?>
                                    <option value="<?= $id?>"><?= $univer ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" class="form-control"
                                   style="width: 35%; margin-top: 5px;"
                                   :name="'NewTeams['+idx+'][ext]'"
                                   placeholder="faculty"
                            >
                        </td>
                        <td>
                            <div id="membersInfo">
                                <div class="row" v-for="(member, mdix) in team.members">
                                    <div class="col-md-11">
                                        <input  type="text"
                                               @dblclick="deleteMember(mdix)"
                                               class="form-control"
                                               style="margin-bottom: 5px"
                                               :name="'NewTeams['+idx+'][members]['+mdix+']'"
                                               placeholder="Member Name"
                                        >
                                    </div>
                                    <div >
                                        <input type="button"
                                               class="btn btn-danger btn-xs"
                                               style="margin-top: 7px"
                                               value="X"
                                               @click="deleteMember(idx)"
                                        >
                                    </div>

                                </div>
                                <input type="button"
                                       class="btn btn-success btn-xs"
                                       style="margin-top: 5px;"
                                       value="+"
                                       @click="addMember1(idx)"
                                >
                            </div>

                        </td>
                        <td>
                            <input type="text" class="form-control col-md-3" style="width: 50px" :name="'NewTeams['+idx+'][point]'">
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="3">
                        <input type="button"
                               class="btn btn-success"
                               value="Add team"
                               @click="addTeam"
                        >
                    </td>
                </tr>
                </tfoot>
            </table>

        </div>
        <!-- /.tab-pane -->
    </div>
    <!-- /.tab-content -->
</div>

<?php ActiveForm::end(); ?>
<script>
    let eventInfo = new Vue({
        el: '#eventCreateInfo',
        data: {
            newTeamId: 1,
            teams: [
                {
                    'text': '',
                    'members': [
                        {
                            'id': '',
                            'name': ''
                        }
                    ]
                }
            ],
        },
        computed: {

        },
        methods: {
            addTeam(){
                this.teams.push(
                    attrs = {
                        text: 'Team '+ this.newTeamId,
                        members: []
                    }
                );
                this.newTeamId++;
            },
            deleteTeam(index){
                this.teams.splice(index, 1);
            },
            deleteMember(index, teams = this.teams[index]){
                teams.members.splice(index, 1);
            },
            addMember1(teamId, teams = this.teams[teamId]){
                teams.members.push(
                    attrs = {
                        id: teamId,
                        name: 'Name member'
                    }
                )
            }
        }
    });
</script>





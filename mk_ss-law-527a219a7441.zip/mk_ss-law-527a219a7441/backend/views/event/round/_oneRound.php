<?php
use yii\helpers\Html;
?>
<?php p($round  )?>
<div class="panel box box-primary">
    <div class="box-header with-border">
        <h4 class="box-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"
               aria-expanded="true" class="">
                <?=

                Html::encode(Yii::t('app', 'Round').' #1') ?>
            </a>
        </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" aria-expanded="true"
         style="">
        <div class="box-body">
            <div class="box box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title">Details</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <dl class="dl-horizontal">
                        <dt><?= Yii::t('app', 'Weight').':';?></dt>
                        <dd><?= $round->weight; ?></dd>
                        <dt><?= Yii::t('app', 'Start date').':';?></dt>
                        <dd><?= $round->date_from?>
                        </dd><dt><?= Yii::t('app', 'End date').':';?></dt>
                        <dd><?= $round->date_to?></dd>
                    </dl>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</div>
<?php

use yii\bootstrap\Modal;
use yii\helpers\Html;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model common\models\Event */

//$this->title = Html::encode($model->getContent()->title);
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Events'), 'url' => ['index']];
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="event-view">

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                'method' => 'post',
            ],
        ]) ?>
    </p>
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-body box-profile">
<!--                    <h3>--><?//= Html::encode($model->getContent()->title); ?><!--</h3> -->

                    <div class="col-md-5">
<!--                        <h3>--><?//= Html::encode($model->getContent()->title); ?><!--</h3>-->
                        <p class="help-block">
                            <code>League:</code> <?= Html::encode($model->league->name)?>
                        </p>
                        <p>
                            <code>date from:</code> <?= Html::encode($model->date_from);?>
                        </p>
                        <p>
                            <code>date to:</code> <?= Html::encode($model->date_to);?>
                        </p>

                    </div>
                    <div class="col-md-7">
                        <div class="box box-solid">
                            <div class="box-header with-border">
                                <h4><?= Yii::t('app', 'Teams') ?></h4>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">

                                <?php Pjax::begin(['id' => 'teamList']) ?>
                                <?php \yii\widgets\ActiveForm::begin([
                                    'id' => 'result-form',
                                    'action' => ['saveresult', 'id' => $model->id],

                                ]); ?>
                                <table class="table table-bordered">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th><?= Yii::t('app', 'Team'); ?></th>
                                        <th><?= Yii::t('app', 'Univer'); ?></th>
                                        <th><?= Yii::t('app', 'Last Round'); ?></th>
<!--                                        <th>--><?//= Yii::t('app', 'Rate'); ?><!--</th>-->
                                    </tr>

                                    <?php
//                                    p($model,1);
                                    foreach ($model->teams as $k => $team):?>
                                        <tr>
                                            <td><?= ++$k; ?></td>
                                            <td>
                                                <?php echo Html::a(
                                                    $team->fullname,
                                                        [
                                                            '/team/view',
                                                            'id' => $team->id
                                                        ]
                                                )
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo Html::encode(
                                                    $team->univer->name
                                                )
                                                ?>
                                            </td>
                                            <td>
                                                <?= Html::encode($team->last_round)?>
<!--                                                --><?php //echo Html::input('text', 'position[' . $team->id . ']',
//                                                    $team->getResultEvent($model) ?
//                                                        $team->getResultEvent($model)['position'] : '',
//                                                    [
//                                                        'class' => 'form-control',
//                                                        'id' => 'position-' . $team->id,
//                                                        'style' => 'width: 40px',
//                                                        $team->getResultEvent($model) ? 'disabled' : ''
//
//                                                    ]
//                                                ) ?>
                                            </td>
<!--                                            <td>-->
<!--                                                --><?//= $team->getResultEvent($model) ?
//                                                   Html::tag('code', $team->getResultEvent($model)['rate']) : '';
//                                                    ?>
<!--                                            </td>-->
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td>
<!--                                            --><?//= Html::a(Yii::t('app', 'Add teams'),
//                                                ['#'],
//                                                [
//                                                    'data-toggle' => 'modal',
//                                                    'data-target' => '#addTeams',
//                                                    'class' => 'btn btn-success',
//                                                    'style' => 'width: 100%; margin-top: 10px'
//                                                ]
//                                            );

                                            ?>
                                        </td>
                                        <td colspan="2"></td>
                                        <td colspan="2">
<!--                                            --><?php //echo Html::submitButton(Yii::t('app', 'Save result'), [
//                                                'id' => 'result-form',
//                                                'class' => 'btn btn-success',
//                                                'style' => 'width: 90px; margin-top: 10px'
//                                            ]) ?>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                                <?php \yii\widgets\ActiveForm::end(); ?>
                                <?php Pjax::end() ?>
                                <!--                                <div class="box-group" id="accordion">-->
                                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                                <!--                                    --><?php //foreach($model->eventRounds as $rk => $round):?>
                                <!--<!--                                        -->
                                <?php ////echo $this->render('round/_oneRound',['round' => $round])?>
                                <!--                                        <div class="panel box box-primary">-->
                                <!--                                            <div class="box-header with-border">-->
                                <!--                                                <h4 class="box-title">-->
                                <!--                                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"-->
                                <!--                                                       aria-expanded="true" class="">-->
                                <!--                                                        --><? //=
                                //
                                //                                                        Html::encode(Yii::t('app', 'Round').' #'.++$rk) ?>
                                <!--                                                    </a>-->
                                <!--                                                </h4>-->
                                <!--                                            </div>-->
                                <!--                                            <div id="collapseOne" class="panel-collapse collapse in" aria-expanded="true"-->
                                <!--                                                 style="">-->
                                <!--                                                <div class="box-body">-->
                                <!--                                                    <div class="box box-solid">-->
                                <!--                                                        <div class="box-header with-border">-->
                                <!--                                                            <h3 class="box-title">Details</h3>-->
                                <!--                                                        </div>-->
                                <!--                                                        <!-- /.box-header -->
                                <!--                                                        <div class="box-body">-->
                                <!--                                                            <dl class="dl-horizontal">-->
                                <!--                                                                <dt>-->
                                <? //= Yii::t('app', 'Weight').':';?><!--</dt>-->
                                <!--                                                                <dd>-->
                                <? //= $round->weight; ?><!--</dd>-->
                                <!--                                                                <dt>-->
                                <? //= Yii::t('app', 'Start date').':';?><!--</dt>-->
                                <!--                                                                <dd>--><? //= $round->date_from?>
                                <!--                                                                </dd><dt>-->
                                <? //= Yii::t('app', 'End date').':';?><!--</dt>-->
                                <!--                                                                <dd>-->
                                <? //= $round->date_to?><!--</dd>-->
                                <!--                                                            </dl>-->
                                <!--                                                        </div>-->
                                <!--                                                        <!-- /.box-body -->
                                <!--                                                    </div>-->
                                <!--                                                </div>-->
                                <!--                                            </div>-->
                                <!--                                        </div>-->
                                <!--                                    --><?php //endforeach; ?>
                                <!--                                </div>-->
                            </div>
                            <!--                            --><? //= Html::a(Yii::t('app', 'Add round'),
                            //                                ['#'],
                            //                                [
                            //                                    'data-toggle' => 'modal',
                            //                                    'data-target' => '#addRound',
                            //                                    'class' => 'btn btn-success',
                            //                                    'style' => 'width: 100%; margin-top: 10px'
                            //                                ]
                            //                            );
                            //
                            //                            ?>
                            <!-- /.box-body -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
Modal::begin([
    'options' => ['id' => 'addTeams'],
    'header' => '<div class="box-body"><h2>' . Yii::t('app', 'Add team to the event') . '</h2></div>',
]);

echo $this->render('_addteam', ['model' => $model]);

Modal::end();
?>

<?php
//Modal::begin([
//    'options' => ['id' => 'addRound'],
//    'header' => '<div class="box-body"><h2>' . Yii::t('app', 'Add round to the event') . '</h2></div>',
//]);
//
//echo $this->render('_addround', ['model' => $model]);
//
//Modal::end();
?>
<script>
    $(document).ready(
        $('#result-form').on('beforeSubmit', function (event, jqXHR, settings) {
            var form = $(this);
            if (form.find('.has-error').length) {
                return false;
            }

            $.ajax({
                url: form.attr('action'),
                type: 'post',
                data: form.serialize(),
                success: function (data) {
                    $.pjax.reload({container: '#teamList'});
                }
            });

            return false;
        }),
    );
</script>

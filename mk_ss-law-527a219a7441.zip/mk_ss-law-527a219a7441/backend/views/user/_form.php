<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="row">
    <div class="col-md-6 user-form">
        <div class="box box-primary">
            <div class="box-body">
                <?php $form = ActiveForm::begin(); ?>

                <?= $form->field($model, 'username')->textInput() ?>

                <div class="form-group field-user-firstname has-success">
                    <label class="control-label" for="user-firstname">Password</label>
                    <?= Html::textInput('User[pass]', '', ['class'=> 'form-control']);?>
                    <div class="help-block"></div>
                </div>

                <?= $form->field($model, 'email')->textInput() ?>
                <?= $form->field($model, 'status')->textInput() ?>

                <div class="box-footer">
                    <div class="form-group">
                        <?= Html::submitButton(
                            $model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'),
                            ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    </div>
                </div>

                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>
</div>
<?php

use kartik\select2\Select2;
use lo\widgets\modal\ModalAjax;
use yii\helpers\Html;
use yii\bootstrap\Modal;
use yii\helpers\Url;
use yii\jui\AutoComplete;
use yii\widgets\ActiveForm;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model common\models\Team */

$this->registerJsFile(
    'js/main.js'
);

$this->title = $model->title;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Teams'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
    <div class="team-view">

        <h1><?= Html::encode(Yii::t('app', 'Team view')) ?></h1>
        <div class="col-md-3">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">

                    <h3 class="profile-username text-center"><?= Html::encode($model->fullname) ?></h3>
                    <p class="text-muted text-center"><?= Html::encode($model->univer->name) ?></p>
                    <?php if (!empty($model->faculty)) : ?>
                        <p class="text-muted text-center">(<?= Html::encode($model->faculty); ?>)</p>
                    <?php endif; ?>
                    <p class="text-muted text-center"><?= Html::encode($model->rate); ?></p>
                    <?php Pjax::begin(['id' => 'teamMemb']) ?>
                    <ul class="list-group list-group-unbordered">
                        <?php foreach ($model->profiles as $profile): ?>
                            <li class="list-group-item">
                                <b><?= Html::a($profile->fullName, ['/profile/view', 'id' => $profile->id]) ?></b>
                            </li>
                        <?php endforeach; ?>
                        <li class="list-group-item">
                            <?= Html::a(Yii::t('app', 'Add member'),
                                ['#'],
                                [
                                    'data-toggle' => 'modal',
                                    'data-target' => '#addMember',
                                    'class' => 'btn btn-success',
                                    'style' => 'width: 100%'
                                ]
                            );

                            ?>
                        </li>
                    </ul>
                    <?php Pjax::end();?>
                </div>
                <div class="box-footer">
                    <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
                    <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
                        'class' => 'btn btn-danger',
                        'data' => [
                            'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                            'method' => 'post',
                        ],
                    ]) ?>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
<?php
Modal::begin([
    'options' => ['id' => 'addMember'],
    'header' => '<div class="box-body"><h2>' . Yii::t('app', 'Add member') . '</h2></div>',
]);

echo $this->render('_addmember', ['model' => $model]);

Modal::end();
?>
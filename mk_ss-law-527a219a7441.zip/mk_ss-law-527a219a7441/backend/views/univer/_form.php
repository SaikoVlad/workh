<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\Univer */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="row">
    <div class="univer-form col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <div class="box-body">
                    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>


                            <?= $form->field($model, 'country')->textInput(['maxlength' => true]) ?>

                            <?= $form->field($model, 'city')->textInput(['maxlength' => true]) ?>

                            <?php echo \vova07\imperavi\Widget::widget([
                                'name' => 'descr',
                                'value' => isset($model->descr) ? $model->descr : '',
                                'settings' => [
                                    'lang' => Yii::$app->language,
                                    'minHeight' => 400,
                                    'plugins' => [
                                        'clips',
                                        'fullscreen'
                                    ]
                                ]
                            ]); ?>

                            <?= $form->field($model, 'visible')->checkbox() ?>
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($model->gerb)):?>
                                <?= Html::img($model->getGerbSrc(),
                                    ['height' => '100px'])?>
                            <?php endif;?>
                            <?= $form->field($model, 'image')->fileInput()?>

                            <?= $form->field($model, 'location')->textInput(['maxlength' => true]) ?>

                            <?= $form->field($model, 'fb')->textInput(['maxlength' => true]) ?>

                            <?= $form->field($model, 'vk')->textInput(['maxlength' => true]) ?>

                            <?= $form->field($model, 'tw')->textInput(['maxlength' => true]) ?>

                            <?= $form->field($model, 'li')->textInput(['maxlength' => true]) ?>

                            <?= $form->field($model, 'contacts')->textarea(['rows' => 6]) ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    </div>

                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>

    </div>
</div>
<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\UniverSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Univers');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="univer-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <!--    --><?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create Univer'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php Pjax::begin(); ?>    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            [
                'attribute' => 'gerb',
                'format' => 'html',

                'value' => function ($data) {
                    return Html::img($data->getGerbSrc(),
                        ['height' => '25px']);
                },
            ],
            'name',
//            'descr:ntext',
            'country',
//            'city',
            // 'contacts:ntext',
//            [
//                    'attribute' => 'rate',
//                    'label' => 'Rating',
////                    'filter' => ''
//
//            ],
            // 'gerb',
            // 'location',
            // 'fb',
            // 'vk',
            // 'tw',
            // 'li',
//            <i class="fa fa-check"></i>
            [
                'attribute' => 'visible',
                'format' => 'raw',
                'filter' => [0 => Yii::t('app','Unvisible'), 1 => Yii::t('app','Visible')],
                    'value' => function ($data) {
                return $data->visible ? Html::tag('i', '', ['class' => 'fa fa-check has-success']) :
                    Html::tag('i', '', ['class' => 'fa fa-close']);
            }
        ],
        // 'order',

        ['class' => 'yii\grid\ActionColumn'],
    ],
    ]); ?>
    <?php Pjax::end(); ?></div>

<?php

use yii\bootstrap\Modal;
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model common\models\Univer */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Univers'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<?php
//    p($model->rate,1);
//?>

<div class="univer-view">

    <span><h1><?= Html::encode($this->title) ?> </h1>
    </span>


    <div class="row">
        <div class="col-md-3">
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <img class="profile-user-img img-responsive img-circle"
                         src="<?= Html::encode($model->getGerbSrc()); ?>"
                         alt="User profile picture">

                    <h3 class="profile-username text-center"><?= Html::encode($model->name) ?></h3>

                    <ul class="list-group list-group-unbordered">
                        <li class="list-group-item">
                            <b><?= Yii::t('app', 'Country') ?></b> <a
                                    class="pull-right"><?= Html::encode($model->country) ?></a>
                        </li>
                        <li class="list-group-item">
                            <b><?= Yii::t('app', 'City') ?></b> <a
                                    class="pull-right"><?= Html::encode($model->city) ?></a>
                        </li>
                        <li class="list-group-item">
                            <b><?= Yii::t('app', 'Rating') ?></b> <a
                                    class="pull-right"><?= Html::encode($model->rate) ?></a>
                        </li>

                    </ul>
                    <div class="box-footer">
                        <p>
                            <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
                            <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
                                'class' => 'btn btn-danger',
                                'data' => [
                                    'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                                    'method' => 'post',
                                ],
                            ]) ?>
                        </p>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>

        <div class="col-md-3">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#activity" data-toggle="tab"
                                          aria-expanded="true"><?= Html::encode(Yii::t('app', 'Students')) ?></a></li>
                    <li class=""><a href="#teams" data-toggle="tab"
                                    aria-expanded="false"><?= Html::encode(Yii::t('app', 'Teams')) ?></a></li>
                    <li class=""><a href="#events" data-toggle="tab"
                                    aria-expanded="false"><?= Html::encode(Yii::t('app', 'Events')) ?></a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="activity">

                        <?php Pjax::begin(['id' => 'univerMemb']) ?>
                        <?php if ($profiles): ?>
                            <?php foreach ($profiles as $profile): ?>
                                <!-- Post -->
                                <div class="post">
                                    <div class="user-block">
                                        <span class="username">
<!--                                            --><? //= Html::a($univer->name, ['/univer/'. $model->id])?>
                                            <?= Html::a($profile->fullname, ['/profile/view', 'id' => $profile->id]) ?>
                                        </span>
                                    </div>
                                    <!-- /.user-block -->
                                    <div class="row margin-bottom">
                                        <!-- /.col -->
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <!-- /.col -->
                                            </div>
                                            <!-- /.row -->
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <?php Pjax::end(); ?>
                        <?= Html::a(Yii::t('app', 'Add students'),
                            ['#'],
                            [
                                'data-toggle' => 'modal',
                                'data-target' => '#addStudets',
                                'class' => 'btn btn-success',
                                'style' => 'width: 100%'
                            ]
                        );

                        ?>

                        <!-- /.post -->
                    </div>
                    <!-- /.tab-pane -->
                    <div class="tab-pane" id="teams">
                        <!-- The timeline -->
                        <?php Pjax::begin(['id' => 'teamList']) ?>
                        <?php if ($model->teams): ?>

                            <?php foreach ($model->teams as $team): ?>
                                <!-- Post -->
                                <div class="post">
                                    <div class="user-block">
                                            <span class="username">
                                                <?= Html::a($team->title, ['/team/view', 'id' => $team->id]) ?>
                                                <?= Html::encode('(' . $team->faculty . ')') ?>
                                                <p class="help-block">rate:
                                                    <code><?= $team->rate ?></code>
                                                </p>
                                            </span>
                                    </div>
                                    <!-- /.user-block -->
                                    <!-- /.row -->
                                </div>
                            <?php endforeach; ?>

                        <?php endif; ?>
                        <?php Pjax::end(); ?>
                        <?= Html::a(Yii::t('app', 'Add team'),
                            ['#'],
                            [
                                'data-toggle' => 'modal',
                                'data-target' => '#addTeams',
                                'class' => 'btn btn-success',
                                'style' => 'width: 100%'
                            ]
                        );

                        ?>

                    </div>
                    <!-- /.tab-pane -->

                    <div class="tab-pane" id="events">
                        <?php foreach ($model->events as $event): ?>
                            <div class="post">
                                <div class="user-block">
                                        <span class="username">
                                            <?= Html::a($event->getContent()->title, ['/event/view', 'id' => $event->id]) ?>
                                        </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- /.nav-tabs-custom -->
        </div>
    </div>
</div>

<?php
Modal::begin([
    'options' => ['id' => 'addStudets'],
    'header' => '<div class="box-body"><h2>' . Yii::t('app', 'Add students') . '</h2></div>',
]);

echo $this->render('_addstudents', ['model' => $model]);

Modal::end();
?>

<?php
Modal::begin([
    'options' => ['id' => 'addTeams'],
    'header' => '<div class="box-body"><h2>' . Yii::t('app', 'Add team') . '</h2></div>',
]);

echo $this->render('_addteam', ['model' => $model]);

Modal::end();
?>

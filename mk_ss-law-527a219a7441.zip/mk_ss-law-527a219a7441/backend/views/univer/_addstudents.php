<?php
use common\models\Profile;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\widgets\Pjax;

?>

<?php
$data = Profile::getListSelect2();
?>

<?php $form = ActiveForm::begin([
    'id' => 'add_stud_univer',
    'options' => ['data-pjax' => true, 'class' => 'form-horizontal'],
    'action' => ['addstudents'],
    'fieldConfig' => ['template' => "<div class=\"col-md-12\">{label}{input}</div>",],
]); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 ">
            <?= Html::hiddenInput('univerId', $model->id) ?>
            <?= '<label class="control-label">Студент</label>';?>

            <?echo  Select2::widget([
                'name' => 'studentId',
                'data' => $data,
                'theme' => Select2::THEME_DEFAULT,
                'options' => ['placeholder' => 'Select studenst...','multiple' => true],
                'pluginOptions' => [
                    'allowClear' => true,
                    'class' => 'form-control'
                ],
            ]);
            ?>
        </div>
    </div>
</div>
<div class="box-footer col-align-right">
    <?= Html::submitButton(Yii::t('app', 'Add'), ['class' => 'btn btn-success']) ?>
    <?= Html::button(Yii::t('app','Close'), ['value' => '#', 'title' => 'close', 'class' => 'btn btn-warning', 'data-dismiss' => 'modal']) ?>
</div>
<?php ActiveForm::end(); ?>

<script type="text/javascript">
    $('#add_stud_univer').on('beforeSubmit', function (e) {
        e.preventDefault();
        var $form = $(this);

        $.post($form.attr("action"), $form.serialize())
            .done(function (result) {
                console.log('done');
                $.pjax.reload({container: '#univerMemb'});
                $('.modal').modal('hide');

            })
            .fail(function () {
                console.log("error");
            });
        return false;
    });
</script>
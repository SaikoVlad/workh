<?php

use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\Profile */
/* @var $form yii\widgets\ActiveForm */
?>

<?php
$data = \common\models\Univer::getListSelect2();
?>

<div class="row">
    <div class="col-md-6 profile-form">
        <div class="box box-primary">
            <div class="box-body">

                <?php $form = ActiveForm::begin(); ?>

                <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'firstname')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

<!--                --><?//= $form->field($model, 'status')->textInput() ?>

                <?= $form->field($model, 'type')->dropDownList(\common\models\Profile::getItemAlias('type')); ?>

                <?= $form->field($model, 'date_br')->widget(
                    DatePicker::className(), [
                        'name' => 'date_br',
                        'type' => DatePicker::TYPE_INPUT,
                        'options' => [
                                'placeholder' => 'Select issue date ...',
                                'value' => date('d.m.Y', $model->date_br)
                        ],
                        'pluginOptions' => [
                            'format' => 'd-m-yyyy',
                            'todayHighlight' => true,
                            'autoClose' => true
                        ]
                ]); ?>
                <div class="form-group field-team-title">
                    <?= Html::tag('label', Yii::t('app', 'Univers',['class' => 'control-label']))?>
                <?echo  Select2::widget([
                    'name' => 'univerId',
                    'data' => $data,
                    'theme' => Select2::THEME_DEFAULT,
                    'options' => ['placeholder' => Yii::t('app','Select univers'). '...','multiple' => true],
                    'pluginOptions' => [
                        'allowClear' => true,
                        'class' => 'form-control'
                    ],
                ]);
                ?>
                </div>

                <?= $form->field($model, 'country')->textInput(['maxlength' => true]) ?>

                <?= $form->field($model, 'city')->textInput(['maxlength' => true]) ?>

                <div class="box-footer">
                    <div class="form-group">
                        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    </div>
                </div>

                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>

</div>

<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Profile */

$this->title = $model->fullname;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Profiles'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="profile-view">
    <h1><?= Html::encode($this->title) ?></h1>
    <div class="row">
        <div class="col-md-3">
            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <h3 class="profile-username text-center"><?= Html::encode($model->fullname) ?></h3>
                    <small><p class="text-center"><?= Html::encode(date('d.m.Y', $model->date_br));?></p></small>

                    <ul class="list-group list-group-unbordered">
                        <li class="list-group-item">
                            <b><?= Yii::t('app', 'Country') ?></b> <a
                                    class="pull-right"><?= Html::encode($model->country) ?></a>
                        </li>
                        <li class="list-group-item">
                            <b><?= Yii::t('app', 'City') ?></b> <a
                                    class="pull-right"><?= Html::encode($model->city) ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Email</b> <a class="pull-right"><?= Html::encode($model->email) ?></a>
                        </li>

                    </ul>
                    <div class="box-footer">
                        <p>
                            <?= Html::a(Yii::t('app', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
                            <?= Html::a(Yii::t('app', 'Delete'), ['delete', 'id' => $model->id], [
                                'class' => 'btn btn-danger',
                                'data' => [
                                    'confirm' => Yii::t('app', 'Are you sure you want to delete this item?'),
                                    'method' => 'post',
                                ],
                            ]) ?>
                        </p>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->

        <div class="col-md-3">
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#activity" data-toggle="tab"
                                          aria-expanded="true"><?= Html::encode(Yii::t('app', 'Univers')) ?></a></li>
                    <li class=""><a href="#teams" data-toggle="tab"
                                    aria-expanded="false"><?= Html::encode(Yii::t('app', 'Teams')) ?></a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="activity">

                        <?php if ($univers): ?>
                            <?php foreach ($univers as $univer): ?>
                                <!-- Post -->
                                <div class="post">
                                    <div class="user-block">
                                        <img class="img-circle img-bordered-sm" src="<?= Html::encode($univer->getGerbSrc());?>"
                                             alt="Univer Gerb">
                                        <span class="username">
<!--                                            --><? //= Html::a($univer->name, ['/univer/'. $model->id])?>
                                            <?= Html::a($univer->name, ['/univer/view', 'id' => $univer->id]) ?>
                                            <!--                                        <a href="/univer/-->
                                            <? //= Html::encode($univer->id)?><!--"> -->
                                            <? //= Html::encode($univer->name) ?><!--</a>-->
                                        </span>
                                    </div>
                                    <!-- /.user-block -->
                                    <div class="row margin-bottom">
                                        <!-- /.col -->
                                        <div class="col-sm-6">
                                            <div class="row">

                                                <!-- /.col -->
                                            </div>
                                            <!-- /.row -->
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <!-- /.post -->
                    </div>
                    <!-- /.tab-pane -->
                    <div class="tab-pane" id="teams">
                        <!-- The timeline -->
                        <?php if ($model->teams): ?>
                            <?php foreach ($model->teams as $team): ?>
                                <!-- Post -->
                                <div class="post">
                                    <div class="user-block">
                                        <span class="username">
                                            <?= Html::a($team->title, ['/team/view', 'id' => $team->id]) ?>
                                        </span>
                                    </div>
                                    <!-- /.user-block -->
                                    <div class="row margin-bottom">
                                        <!-- /.col -->
                                        <div class="col-sm-6">
                                            <div class="row">

                                                <!-- /.col -->
                                            </div>
                                            <!-- /.row -->
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- /.nav-tabs-custom -->
        </div>
    </div>
</div>

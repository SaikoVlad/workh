<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\NewsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'News');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="news-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create News'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php Pjax::begin(); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'link',
            [
                'attribute' => 'category_id',
                'format' => 'raw',
                'filter' => \common\models\NewsCategory::getCategoryList(1),
                'value' => function($data){
                    return $data->category->name;
                },
            ],
            'meta_keys',
            'meta_descr',
            [
                'attribute' => 'visible',
                'format' => 'raw',
                'filter' => [0 => Yii::t('app', 'Unvisible'), 1 => Yii::t('app', 'Visible')],
                'value' => function ($data) {
                    return $data->visible ? Html::tag('i', '', ['class' => 'fa fa-check has-success']) :
                        Html::tag('i', '', ['class' => 'fa fa-close']);
                }
            ],

            ['class' => 'yii\grid\ActionColumn',
                'template' => '{update} {delete}'],
        ],
    ]); ?>
    <?php Pjax::end(); ?></div>

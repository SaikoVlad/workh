<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\News */
/* @var $form yii\widgets\ActiveForm */
?>
    <div class="row">
        <div class="col-md-12 news-form">
            <div class="box box-primary">
                <div class="box-header with-border">
                </div>
                <div class="box-body">

                    <?php $form = ActiveForm::begin(); ?>

                    <div class="col-md-3">
                        <?= $form->field($model, 'link')->textInput(['maxlength' => true]) ?>

                        <?= $form->field($model, 'category_id')->dropDownList(\common\models\NewsCategory::getCategoryList(1)) ?>

                        <?= $form->field($model, 'meta_keys')->textInput(['maxlength' => true]) ?>

                        <?= $form->field($model, 'meta_descr')->textInput(['maxlength' => true]) ?>

                        <?= $form->field($model, 'visible')->checkbox() ?>
                    </div>

                    <div class="col-md-9">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#en" data-toggle="tab"
                                                      aria-expanded="true">EN</a></li>
                                <li class=""><a href="#ru" data-toggle="tab"
                                                aria-expanded="false">RU</a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="en">
                                    <?= Html::input('hidden', 'NewsFull[en][lang]', 'en') ?>
                                    <div class="form-group field-news-link">
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Title')) ?>
                                        </label>
                                        <?= Html::input('text', 'NewsFull[en][title]', isset($enContent->title) ? $enContent->title : '', ['class' => 'form-control']) ?>
                                    </div>
                                    <?php echo \vova07\imperavi\Widget::widget([
                                        'name' => 'NewsFull[en][content]',
                                        'value' => isset($enContent->content) ? $enContent->content : '',
                                        'settings' => [
                                            'lang' => 'en',
                                            'minHeight' => 400,
                                            'plugins' => [
                                                'clips',
                                                'fullscreen'
                                            ]
                                        ]
                                    ]); ?>
                                </div>
                                <div class="tab-pane" id="ru">
                                    <?= Html::input('hidden', 'NewsFull[ru][lang]', 'ru') ?>
                                    <div class="form-group field-news-link">
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Title')) ?>
                                        </label>
                                        <?= Html::input('text', 'NewsFull[ru][title]', isset($ruContent->title) ? $ruContent->title : '', ['class' => 'form-control']) ?>
                                    </div>
                                    <?php
                                    echo \vova07\imperavi\Widget::widget([
                                        'name' => 'NewsFull[ru][content]',
                                        'value' => isset($ruContent->content) ? $ruContent->content : '',
                                        'settings' => [
                                            'lang' => 'ru',
                                            'minHeight' => 400,
                                            'plugins' => [
                                                'clips',
                                                'fullscreen'
                                            ]
                                        ]
                                    ]); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="box-footer">
                        <div class="form-group">
                            <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                        </div>
                    </div>

            </div>
        </div>
    </div>
<?php ActiveForm::end(); ?>
<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\News */
/* @var $form yii\widgets\ActiveForm */
?>
    <div class="row">
        <div class="col-md-12 news-form">
            <div class="box box-primary">
                <div class="box-header with-border">
                </div>
                <div class="box-body">

                    <?php $form = ActiveForm::begin(); ?>

                    <div class="col-md-3">
                        <?= $form->field($model, 'link')->textInput(['maxlength' => true]) ?>
                        <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
                        <?= $form->field($model, 'found_date')->textInput(['maxlength' => true]) ?>
                        <?= $form->field($model, 'parent_id')->dropDownList(\common\models\League::getParentList($model->id),['prompt'=>'']) ?>
<!---->
<!--                        --><?//= $form->field($model, 'meta_descr')->textInput(['maxlength' => true]) ?>

<!--                        --><?//= $form->field($model, 'visible')->checkbox() ?>
                    </div>

                    <div class="col-md-9">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#en" data-toggle="tab"
                                                      aria-expanded="true">EN</a></li>
                                <li class=""><a href="#ru" data-toggle="tab"
                                                aria-expanded="false">RU</a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="en">
                                    <?= Html::input('hidden', 'LeagueContent[en][lang]', 'en') ?>
                                    <div class="form-group field-news-link">
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Title')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[en][title]', isset($enContent->title) ? $enContent->title : '', ['class' => 'form-control']) ?>
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Meta title')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[en][meta_title]', isset($enContent->meta_title) ? $enContent->meta_title : '', ['class' => 'form-control']) ?>
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Meta keys')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[en][meta_keys]', isset($enContent->meta_keys) ? $enContent->meta_keys : '', ['class' => 'form-control']) ?>
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Meta descr')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[en][meta_descr]', isset($enContent->meta_descr) ? $enContent->meta_descr : '', ['class' => 'form-control']) ?>
                                    </div>
                                    <?php echo \vova07\imperavi\Widget::widget([
                                        'name' => 'LeagueContent[en][body]',
                                        'value' => isset($enContent->body) ? $enContent->body : '',
                                        'settings' => [
                                            'lang' => 'en',
                                            'minHeight' => 200,
                                            'plugins' => [
                                                'clips',
                                                'fullscreen'
                                            ]
                                        ]
                                    ]); ?>
                                </div>
                                <div class="tab-pane" id="ru">
                                    <?= Html::input('hidden', 'LeagueContent[ru][lang]', 'ru') ?>
                                    <div class="form-group field-news-link">
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Title')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[ru][title]', isset($ruContent->title) ? $ruContent->title : '', ['class' => 'form-control']) ?>
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Meta title')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[ru][meta_title]', isset($ruContent->meta_title) ? $ruContent->meta_title : '', ['class' => 'form-control']) ?>
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Meta keys')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[ru][meta_keys]', isset($ruContent->meta_keys) ? $ruContent->meta_keys : '', ['class' => 'form-control']) ?>
                                        <label class="control-label" for="news-link">
                                            <?= Html::encode(Yii::t('app', 'Meta descr')) ?>
                                        </label>
                                        <?= Html::input('text', 'LeagueContent[ru][meta_descr]', isset($ruContent->meta_descr) ? $ruContent->meta_descr : '', ['class' => 'form-control']) ?>
                                    </div>
                                    <?php
                                    echo \vova07\imperavi\Widget::widget([
                                        'name' => 'LeagueContent[ru][body]',
                                        'value' => isset($ruContent->body) ? $ruContent->body : '',
                                        'settings' => [
                                            'lang' => 'ru',
                                            'minHeight' => 200,
                                            'plugins' => [
                                                'clips',
                                                'fullscreen'
                                            ]
                                        ]
                                    ]); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <div class="form-group">
                        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Create') : Yii::t('app', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php ActiveForm::end(); ?>
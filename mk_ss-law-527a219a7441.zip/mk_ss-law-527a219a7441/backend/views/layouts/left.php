<aside class="main-sidebar">

    <section class="sidebar">
        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu'],
                'items' => [
                    ['label' => 'MAIN NAVIGATION', 'options' => ['class' => 'header']],
//                    ['label' => Yii::t('app', 'Profiles') , 'icon' => 'user', 'url' => ['/profile']],
                    ['label' => Yii::t('app', 'Universities') , 'icon' => 'bank', 'url' => ['/univer']],
                    ['label' => Yii::t('app', 'Teams') , 'icon' => 'users', 'url' => ['/team']],
                    ['label' => Yii::t('app', 'News') , 'icon' => 'newspaper-o', 'url' => ['/news']],
                    ['label' => Yii::t('app', 'Moot courts') , 'icon' => 'rocket', 'url' => ['/event']],
                    ['label' => Yii::t('app', 'League') , 'icon' => 'rocket', 'url' => ['/league']],
                    ['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                    [
                        'label' => 'Site tools',
                        'icon' => 'gears',
                        'url' => '#',
                        'items' => [
                            ['label' => Yii::t('app', 'Users') , 'icon' => 'users', 'url' => ['/user']],
                            ['label' => 'Gii', 'icon' => 'file-code-o', 'url' => ['/gii'],],
                            ['label' => 'Test', 'icon' => 'file-code-o', 'url' => ['/team/test'],],
                            ['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug'],],
                        ],
                    ],
                ],
            ]
        ) ?>

    </section>

</aside>

<?php
return [
    'test' => 'тест'

];